age = input("What is your age? ")
sex = input("What is your sex? ")
state = input("What state do you live in?") 
print("Your age is", age, "You are a", sex, "You live in", state)
#Project idea is a website that displays covid-19 death statistics. Users will input their age, sex, and residency information and get a statistic about how many people matching their demographic has died. The goal is to inform and to encourage people to get vaccinated.
a = 0
b = 17
c = 18
d = 29
e = 30
f = 39
#I want this to say if age is less than 17 but more than 0, display certain statistic
if a < b:
  print("159 deaths")
elif c < d:
  print("992 deaths")
elif e < f:
  print("2697 deaths")
#will add more age ranges plus sex and state statistics


